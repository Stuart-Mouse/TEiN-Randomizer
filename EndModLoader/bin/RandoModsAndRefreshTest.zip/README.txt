------------------------------------------------------------------

INSTALLATION:

Simply extract the zip folder you downloaded and leave everything 
inside the "Release" folder, no need to go dumping eveything in 
your TEiN folder and get things mixed up.

------------------------------------------------------------------

PLAYING THE RANDOMIZER:

Run the TEiNRandomizer.exe

The Menu:
On the left side of the menu, you will see the level pools.
You can turn these on and off with the "Enabled" checkbox. (I think nevermore is broken right now so that maybe dont activate that one yet)
On the right side of the menu is the settings.
These should mostly be self-explanatory.
Levels is how many levels will be genereted PER AREA.
Areas is how many set of levels will be generated.
If "One Tileset per Area" is checked, each area will use a contiguous theme. (same palette, music, particles, etc.)

Ready to Play?:
Once you have your settings the way you like them, click the "Randomize" button at the bottom left.
This should automatically boot the game.
Once in game, go to 1-1. There should be a new hole in the floor. Go down it to begin playing the randomizer.
(currently theres a broken tileset on the entryway levels but ill fix that later, okay?)

If you get any crashes just hmu (stuart_mouse@protonmail.com)

------------------------------------------------------------------

CREDITS:

Stuart Mouse   - main developer of the randomizer
portal-chan    - created the endmodloader (which this program is built upon)
ButcherBerries - playtesting
Aurielle       - SWF modding
Hapax          - come on and finish the endonighzer already, geez

~ and ~
the rest of the TEiN modding community

------------------------------------------------------------------